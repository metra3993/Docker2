const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());        // 🔥 разрешаем фронту стучаться сюда
app.use(express.json());

let savedTimes = [];

app.get('/', (req, res) => {
  res.send('Hello from the time saving service!');
});

app.get('/times', (req, res) => {
  res.json(savedTimes);
});

app.post('/times', (req, res) => {
  const { time } = req.body;
  if (time) {
    savedTimes.push(time);
    res.json({ success: true });
  } else {
    res.status(400).json({ success: false, error: 'time is required' });
  }
});

app.delete('/times/:id', (req, res) => {
  const id = parseInt(req.params.id);
  if (!isNaN(id) && id >= 0 && id < savedTimes.length) {
    savedTimes.splice(id, 1);
    res.json({ success: true });
  } else {
    res.status(404).json({ success: false, error: 'invalid id' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`API running on port ${PORT}`);
});
